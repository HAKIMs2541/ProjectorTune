package app.projectortune.launcher

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket

/** รับคำสั่ง/ภาพจากแอปบนมือถือ โดยไม่ใช้ ADB */
class HostService : Service() {
    companion object {
        const val TCP_PORT = 40402
        const val UDP_PORT = 40401

        @Volatile
        var running = false

        @Volatile
        var connected = false

        fun start(c: Context) {
            val i = Intent(c, HostService::class.java)
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i) else c.startService(i)
        }
    }

    private var tcp: ServerSocket? = null
    private var udp: DatagramSocket? = null
    private var mlock: WifiManager.MulticastLock? = null

    @Volatile
    private var current: Socket? = null

    @Volatile
    private var fails = 0

    @Volatile
    private var lockedUntil = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!running) {
            running = true
            startFg()
            try {
                val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                mlock = wm.createMulticastLock("pt").also {
                    it.setReferenceCounted(false)
                    it.acquire()
                }
            } catch (e: Throwable) {
            }
            Thread { udpLoop() }.start()
            Thread { tcpLoop() }.start()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        runCatching { tcp?.close() }
        runCatching { udp?.close() }
        runCatching { mlock?.release() }
        super.onDestroy()
    }

    private fun startFg() {
        val b: Notification.Builder
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel("pt", "ProjectorTune", NotificationManager.IMPORTANCE_MIN)
            )
            b = Notification.Builder(this, "pt")
        } else {
            b = Notification.Builder(this)
        }
        val n = b.setContentTitle("ProjectorTune พร้อมรับการควบคุมจากมือถือ")
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .build()
        startForeground(1, n)
    }

    private fun udpLoop() {
        try {
            val s = DatagramSocket(null)
            s.reuseAddress = true
            s.bind(InetSocketAddress(UDP_PORT))
            udp = s
            val buf = ByteArray(256)
            while (running) {
                val p = DatagramPacket(buf, buf.size)
                s.receive(p)
                if (String(p.data, 0, p.length).trim() == "PT_DISCOVER") {
                    val r = "PT_HERE|${Store.deviceId(this)}|${Build.MODEL}|$TCP_PORT".toByteArray()
                    s.send(DatagramPacket(r, r.size, p.address, p.port))
                }
            }
        } catch (e: Throwable) {
        }
    }

    private fun tcpLoop() {
        try {
            val ss = ServerSocket()
            ss.reuseAddress = true
            ss.bind(InetSocketAddress(TCP_PORT))
            tcp = ss
            while (running) {
                val c = ss.accept()
                Thread { serve(c) }.start()
            }
        } catch (e: Throwable) {
        }
    }

    private fun reply(out: DataOutputStream, j: JSONObject) {
        Proto.write(out, Proto.T_JSON, j.toString().toByteArray())
    }

    private fun serve(sock: Socket) {
        var mine = false
        try {
            sock.tcpNoDelay = true
            sock.soTimeout = 15000
            val inp = DataInputStream(BufferedInputStream(sock.getInputStream()))
            val out = DataOutputStream(BufferedOutputStream(sock.getOutputStream()))

            val first = Proto.read(inp)
            if (first.first != Proto.T_JSON) return
            val h = JSONObject(String(first.second))
            val tok = h.optString("token")
            val pin = h.optString("pin")
            val now = System.currentTimeMillis()
            var newTok: String? = null
            var ok = false
            if (tok.isNotEmpty() && Store.tokens(this).contains(tok)) {
                ok = true
            } else if (pin.isNotEmpty() && now > lockedUntil) {
                if (pin == Store.pin(this)) {
                    ok = true
                    newTok = Store.randomHex(16)
                    Store.addToken(this, newTok)
                    Store.newPin(this)
                    fails = 0
                } else {
                    fails++
                    if (fails >= 5) {
                        lockedUntil = now + 60000
                        fails = 0
                        Store.newPin(this)
                    }
                }
            }
            if (!ok) {
                val msg = if (now <= lockedUntil) "ลองผิดหลายครั้ง รอ 1 นาที" else "รหัสไม่ถูกต้อง"
                reply(out, JSONObject().put("t", "err").put("m", msg))
                return
            }
            val okJson = JSONObject().put("t", "ok").put("id", Store.deviceId(this)).put("name", Build.MODEL)
            if (newTok != null) okJson.put("token", newTok)
            reply(out, okJson)

            // เหลือการเชื่อมต่อเดียว
            runCatching { current?.close() }
            current = sock
            mine = true
            connected = true
            sock.soTimeout = 0

            while (running) {
                val f = Proto.read(inp)
                when (f.first) {
                    Proto.T_JSON -> handle(JSONObject(String(f.second)), out)
                    Proto.T_CONFIG -> Cast.config = f.second
                    Proto.T_VIDEO -> Cast.offer(f.second)
                }
            }
        } catch (e: Throwable) {
        } finally {
            if (mine && current === sock) {
                connected = false
                current = null
                Cast.stop()
            }
            runCatching { sock.close() }
        }
    }

    private fun handle(j: JSONObject, out: DataOutputStream) {
        when (j.optString("t")) {
            "key" -> Remote.key(this, j.optString("k"))
            "tap" -> TuneAccessibilityService.instance?.tap(
                j.optDouble("x", 0.5).toFloat(), j.optDouble("y", 0.5).toFloat()
            )
            "swipe" -> TuneAccessibilityService.instance?.swipe(
                j.optDouble("x1").toFloat(), j.optDouble("y1").toFloat(),
                j.optDouble("x2").toFloat(), j.optDouble("y2").toFloat(),
                j.optLong("ms", 300)
            )
            "vol" -> volume(j.optInt("d", 0))
            "apps" -> {
                val hidden = Store.hidden(this)
                val arr = JSONArray()
                for (a in Apps.list(this, true)) {
                    arr.put(JSONObject().put("p", a.pkg).put("n", a.label).put("h", a.pkg in hidden))
                }
                reply(out, JSONObject().put("t", "apps").put("list", arr))
            }
            "launch" -> Apps.launch(this, j.optString("pkg"))
            "hide" -> Store.setHidden(this, j.optString("pkg"), j.optBoolean("on", true))
            "play" -> {
                val u = j.optString("url")
                if (u.startsWith("http://") || u.startsWith("https://")) VideoActivity.start(this, u)
            }
            "media" -> VideoActivity.control(j.optString("a"), j.optInt("ms", 0))
            "cast_start" -> {
                Cast.start(j.optInt("w", 1280), j.optInt("h", 720))
                val i = Intent(this, CastActivity::class.java)
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                startActivity(i)
            }
            "cast_stop" -> Cast.stop()
            "info" -> {
                val mem = try {
                    java.io.File("/proc/meminfo").readLines().take(3).joinToString(" | ")
                } catch (e: Throwable) {
                    ""
                }
                reply(
                    out,
                    JSONObject().put("t", "info")
                        .put("text", "${Build.MODEL} · Android ${Build.VERSION.RELEASE}\n$mem")
                )
            }
        }
    }

    private fun volume(d: Int) {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val dir = when {
            d > 0 -> AudioManager.ADJUST_RAISE
            d < 0 -> AudioManager.ADJUST_LOWER
            else -> AudioManager.ADJUST_TOGGLE_MUTE
        }
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI)
    }
}
