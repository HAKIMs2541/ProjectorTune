package app.projectortune

import android.app.Activity
import android.content.Context
import android.media.projection.MediaProjectionManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ---------- ชิ้นส่วนที่ใช้ซ้ำ ----------

@Composable
fun Panel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .background(C.card)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        content = content
    )
}

@Composable
fun Title(text: String) {
    Text(text, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = C.text)
}

@Composable
fun Hint(text: String) {
    Text(text, fontSize = 13.sp, color = C.gray, lineHeight = 19.sp)
}

@Composable
fun BigButton(text: String, enabled: Boolean = true, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        enabled = enabled,
        shape = RoundedCornerShape(18.dp),
        colors = ButtonDefaults.buttonColors(containerColor = C.blue, contentColor = Color.White),
        modifier = Modifier.fillMaxWidth().height(58.dp)
    ) { Text(text, fontSize = 18.sp, fontWeight = FontWeight.Medium) }
}

@Composable
fun StepRow(s: Step) {
    val color = when (s.st) {
        St.WAIT -> C.card2
        St.RUN -> C.blue
        St.OK -> C.green
        St.SKIP -> C.gray
        St.FAIL -> C.red
    }
    val mark = when (s.st) {
        St.WAIT -> ""
        St.RUN -> "…"
        St.OK -> "✓"
        St.SKIP -> "–"
        St.FAIL -> "✕"
    }
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(26.dp).clip(CircleShape).background(color), contentAlignment = Alignment.Center) {
            Text(mark, color = Color.Black, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(s.name, fontSize = 15.sp, color = if (s.st == St.WAIT) C.gray else C.text)
            if (s.note.isNotBlank()) Text(s.note, fontSize = 12.sp, color = C.gray)
        }
    }
}

@Composable
fun LogBox(vm: MainVm) {
    if (vm.log.isNotBlank()) Text(vm.log, fontSize = 12.sp, color = C.gray, modifier = Modifier.fillMaxWidth())
}

// ---------- หน้าเริ่ม ----------

@Composable
fun HomeScreen(vm: MainVm) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(painterResource(R.drawable.ic_logo), contentDescription = "โลโก้ ProjectorTune", modifier = Modifier.size(60.dp))
            Spacer(Modifier.width(14.dp))
            Column {
                Text("ProjectorTune", fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Text("สร้างโดย HAKIM", fontSize = 13.sp, color = C.gray)
            }
        }

        Panel {
            val on = Link.state == "on"
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(10.dp).clip(CircleShape).background(if (on) C.green else C.gray))
                Spacer(Modifier.width(10.dp))
                Text(
                    if (on) "${Link.tvName} · เชื่อมต่อแล้ว" else "ยังไม่ได้เชื่อมต่อโปรเจคเตอร์",
                    fontSize = 16.sp, fontWeight = FontWeight.Medium
                )
            }
            Hint("ADB: ${vm.status}")
            if (vm.info.isNotBlank()) Hint(vm.info)
        }

        BigButton("เริ่มปรับแต่งอัตโนมัติ", enabled = !vm.busy) { vm.startAuto() }

        if (vm.steps.isNotEmpty()) {
            Panel { vm.steps.forEach { StepRow(it) } }
        } else {
            Panel {
                Title("ทำอะไรให้บ้าง")
                Hint(
                    "1. เชื่อมต่อโปรเจคเตอร์ (ครั้งแรกกดอนุญาตบนหน้าจอโปรเจคเตอร์)\n" +
                        "2. ติดตั้ง Launcher สไตล์คลีนของ ProjectorTune เป็นหน้าหลัก\n" +
                        "3. ปิดแอปโฆษณา/ขยะแบบย้อนกลับได้\n" +
                        "4. หลังจากนั้นควบคุมและฉายหน้าจอผ่าน Wi-Fi ได้เลย ไม่ต้องใช้ ADB อีก"
                )
            }
        }

        Panel {
            Title("เชื่อมต่อด้วยตัวเอง (ไม่บังคับ)")
            Hint(
                "บนโปรเจคเตอร์: ตั้งค่า > เกี่ยวกับ กด Build number 7 ครั้ง แล้วเปิด USB debugging " +
                    "จากนั้นให้มือถือและโปรเจคเตอร์อยู่ Wi-Fi เดียวกัน"
            )
            OutlinedTextField(
                value = vm.host,
                onValueChange = { vm.host = it },
                label = { Text("IP ของโปรเจคเตอร์ เช่น 192.168.1.50") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { vm.scan() }, enabled = !vm.busy) { Text("สแกนหา") }
                FilledTonalButton(onClick = { vm.connect() }, enabled = !vm.busy) { Text("เชื่อมต่อ ADB") }
                if (vm.connected) TextButton(onClick = { vm.disconnect() }) { Text("ตัดการเชื่อมต่อ") }
            }
            vm.found.forEach { ip -> TextButton(onClick = { vm.host = ip }) { Text(ip) } }
            LogBox(vm)
        }
    }
}

// ---------- หน้าควบคุม ----------

@Composable
fun KeyBtn(label: String, k: String, wide: Boolean = false) {
    FilledTonalButton(
        onClick = { Link.key(k) },
        shape = RoundedCornerShape(16.dp),
        contentPadding = PaddingValues(0.dp),
        modifier = Modifier.size(if (wide) 88.dp else 72.dp, 56.dp)
    ) { Text(label, fontSize = 18.sp) }
}

@Composable
fun RemoteScreen(vm: MainVm) {
    val ctx = LocalContext.current
    val capture = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val d = r.data
        if (r.resultCode == Activity.RESULT_OK && d != null) vm.castStart(r.resultCode, d)
    }

    if (vm.pinFor != null) {
        AlertDialog(
            onDismissRequest = { vm.pinFor = null },
            containerColor = C.card2,
            title = { Text("ใส่รหัสจับคู่") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("ดูรหัส 4 หลักที่มุมซ้ายล่างของหน้าจอโปรเจคเตอร์", fontSize = 14.sp)
                    OutlinedTextField(
                        value = vm.pinInput,
                        onValueChange = { vm.pinInput = it.filter { c -> c.isDigit() }.take(4) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )
                    if (vm.tvMsg.isNotBlank()) Text(vm.tvMsg, color = C.orange, fontSize = 13.sp)
                }
            },
            confirmButton = { TextButton(onClick = { vm.submitPin() }) { Text("ยืนยัน") } },
            dismissButton = { TextButton(onClick = { vm.pinFor = null }) { Text("ยกเลิก") } }
        )
    }

    if (Link.state != "on") {
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("ควบคุมโปรเจคเตอร์", fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Panel {
                Title("เชื่อมต่อไร้สาย")
                Hint(
                    "ต้องติดตั้ง Launcher ของ ProjectorTune บนโปรเจคเตอร์ก่อน (ปุ่ม 'เริ่มปรับแต่งอัตโนมัติ' ที่แท็บเริ่ม) " +
                        "หลังจากนั้นไม่ต้องใช้ ADB อีก"
                )
                BigButton("ค้นหาโปรเจคเตอร์", enabled = !vm.busy) { vm.discoverTv() }
                vm.tvFound.forEach { f ->
                    FilledTonalButton(
                        onClick = { vm.pickTv(f) },
                        modifier = Modifier.fillMaxWidth().height(52.dp),
                        shape = RoundedCornerShape(14.dp)
                    ) { Text("${f.name} · ${f.ip}") }
                }
                val last = Link.lastIp()
                if (last.isNotEmpty()) {
                    OutlinedButton(
                        onClick = { vm.pickTv(Link.Found("", "เครื่องล่าสุด", last, 40402)) },
                        modifier = Modifier.fillMaxWidth().height(48.dp)
                    ) { Text("เชื่อมต่อเครื่องล่าสุด ($last)") }
                }
                if (vm.tvMsg.isNotBlank() && vm.pinFor == null) Hint(vm.tvMsg)
                if (Link.error.isNotBlank()) Text(Link.error, color = C.orange, fontSize = 13.sp)
            }
        }
        return
    }

    val rows = Link.apps.filter { !it.hidden }.chunked(3)
    LazyColumn(
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Panel {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(10.dp).clip(CircleShape).background(C.green))
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(Link.tvName, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        Text(Link.tvIp, fontSize = 12.sp, color = C.gray)
                    }
                    TextButton(onClick = { vm.tvDisconnect() }) { Text("ตัดการเชื่อมต่อ") }
                }
                if (Link.info.isNotBlank()) Hint(Link.info)
            }
        }
        item {
            Panel {
                Title("ฉายหน้าจอมือถือ")
                Hint("แสดงภาพหน้าจอมือถือบนโปรเจคเตอร์ (ภาพอย่างเดียว ยังไม่มีเสียง)")
                if (Link.casting) {
                    Button(
                        onClick = { vm.castStop() },
                        colors = ButtonDefaults.buttonColors(containerColor = C.red),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth().height(52.dp)
                    ) { Text("หยุดฉาย") }
                } else {
                    BigButton("เริ่มฉายหน้าจอ") {
                        val mpm = ctx.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                        capture.launch(mpm.createScreenCaptureIntent())
                    }
                }
            }
        }
        item {
            Panel {
                Title("รีโมต")
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    KeyBtn("▲", "UP")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        KeyBtn("◀", "LEFT")
                        KeyBtn("OK", "OK", wide = true)
                        KeyBtn("▶", "RIGHT")
                    }
                    KeyBtn("▼", "DOWN")
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick = { Link.key("BACK") }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(0.dp)) { Text("ย้อนกลับ", fontSize = 12.sp, maxLines = 1) }
                    OutlinedButton(onClick = { Link.key("HOME") }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(0.dp)) { Text("หน้าหลัก", fontSize = 12.sp, maxLines = 1) }
                    OutlinedButton(onClick = { Link.vol(-1) }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(0.dp)) { Text("เสียง -", fontSize = 12.sp, maxLines = 1) }
                    OutlinedButton(onClick = { Link.vol(1) }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(0.dp)) { Text("เสียง +", fontSize = 12.sp, maxLines = 1) }
                    OutlinedButton(onClick = { Link.vol(0) }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(0.dp)) { Text("ปิดเสียง", fontSize = 12.sp, maxLines = 1) }
                }
            }
        }
        item {
            Panel {
                Title("ทัชแพด")
                Hint("แตะ/ปัดบนกรอบนี้ = แตะ/ปัดตำแหน่งเดียวกันบนจอโปรเจคเตอร์ (ใช้ได้กับแอปอื่น)")
                Box(
                    Modifier
                        .fillMaxWidth()
                        .aspectRatio(16f / 9f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(C.card2)
                        .pointerInput(Unit) {
                            detectTapGestures { o ->
                                Link.tap(o.x / size.width, o.y / size.height)
                            }
                        }
                        .pointerInput(Unit) {
                            var sx = 0f
                            var sy = 0f
                            var cx = 0f
                            var cy = 0f
                            detectDragGestures(
                                onDragStart = { o ->
                                    sx = o.x / size.width
                                    sy = o.y / size.height
                                    cx = sx
                                    cy = sy
                                },
                                onDrag = { change, _ ->
                                    cx = change.position.x / size.width
                                    cy = change.position.y / size.height
                                },
                                onDragEnd = { Link.swipe(sx, sy, cx, cy) }
                            )
                        },
                    contentAlignment = Alignment.Center
                ) { Text("ทัชแพด", color = C.gray, fontSize = 13.sp) }
            }
        }
        item {
            Panel {
                Title("เล่นวิดีโอจากลิงก์")
                OutlinedTextField(
                    value = vm.castUrl,
                    onValueChange = { vm.castUrl = it },
                    label = { Text("ลิงก์วิดีโอ (mp4 / m3u8)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                FilledTonalButton(onClick = { vm.playUrl() }) { Text("เล่นบนโปรเจคเตอร์") }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick = { Link.media("seek", -10000) }, contentPadding = PaddingValues(12.dp, 0.dp)) { Text("-10 วิ", fontSize = 12.sp) }
                    OutlinedButton(onClick = { Link.media("toggle") }, contentPadding = PaddingValues(12.dp, 0.dp)) { Text("เล่น/หยุด", fontSize = 12.sp) }
                    OutlinedButton(onClick = { Link.media("seek", 10000) }, contentPadding = PaddingValues(12.dp, 0.dp)) { Text("+10 วิ", fontSize = 12.sp) }
                    OutlinedButton(onClick = { Link.media("stop") }, contentPadding = PaddingValues(12.dp, 0.dp)) { Text("ปิด", fontSize = 12.sp) }
                }
            }
        }
        item { Title("แอปบนโปรเจคเตอร์") }
        items(rows) { r ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                r.forEach { a ->
                    FilledTonalButton(
                        onClick = { Link.launch(a.pkg) },
                        shape = RoundedCornerShape(14.dp),
                        contentPadding = PaddingValues(6.dp, 0.dp),
                        modifier = Modifier.weight(1f).height(54.dp)
                    ) { Text(a.label, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp) }
                }
                repeat(3 - r.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

// ---------- หน้าแอป (ใช้ ADB) ----------

@Composable
fun AppsScreen(vm: MainVm) {
    var pending by remember { mutableStateOf<Pkg?>(null) }
    LaunchedEffect(vm.connected) {
        if (vm.connected && vm.pkgs.isEmpty()) vm.loadPackages()
    }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("แอปในโปรเจคเตอร์", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        if (!vm.connected) {
            Spacer(Modifier.height(10.dp))
            Hint("หน้านี้ใช้ ADB เชื่อมต่อที่แท็บเริ่มก่อน (ถ้าปิด ADB ไปแล้ว ต้องเปิด USB debugging ใหม่)")
        } else {
            OutlinedTextField(
                value = vm.query,
                onValueChange = { vm.query = it },
                label = { Text("ค้นหาแอป") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Switch(checked = vm.showSystem, onCheckedChange = { vm.showSystem = it })
                Text("แสดงแอประบบ", fontSize = 13.sp, modifier = Modifier.weight(1f))
                TextButton(onClick = { vm.loadPackages() }) { Text("รีเฟรช") }
                TextButton(onClick = { vm.restoreAll() }) { Text("กู้คืนทั้งหมด") }
            }
            val list = vm.pkgs.filter { (vm.showSystem || !it.system) && it.name.contains(vm.query, true) }
            LazyColumn(Modifier.weight(1f)) {
                items(list, key = { it.name }) { p ->
                    val r = vm.risk(p.name)
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(p.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
                            val tags = listOfNotNull(
                                if (p.system) "ระบบ" else "ผู้ใช้",
                                if (p.disabled) "ปิดอยู่" else null,
                                when (r) {
                                    Risk.PROTECTED -> "ห้ามแตะ"
                                    Risk.SUSPECT -> "สงสัยโฆษณา/ติดตาม"
                                    Risk.NORMAL -> null
                                }
                            )
                            Text(
                                tags.joinToString(" · "), fontSize = 12.sp,
                                color = if (r == Risk.SUSPECT) C.orange else C.gray
                            )
                        }
                        if (r != Risk.PROTECTED) {
                            if (p.disabled) OutlinedButton(onClick = { vm.toggle(p) }) { Text("เปิดใช้") }
                            else Button(onClick = { pending = p }) { Text("ปิด") }
                        }
                    }
                    HorizontalDivider(color = C.card2)
                }
            }
            LogBox(vm)
        }
    }
    pending?.let { p ->
        AlertDialog(
            onDismissRequest = { pending = null },
            containerColor = C.card2,
            title = { Text("ปิดแอปนี้?") },
            text = { Text("${p.name}\n\nปิดแบบย้อนกลับได้ (กด เปิดใช้ หรือ กู้คืนทั้งหมด)") },
            confirmButton = { TextButton(onClick = { vm.toggle(p); pending = null }) { Text("ปิดแอป") } },
            dismissButton = { TextButton(onClick = { pending = null }) { Text("ยกเลิก") } }
        )
    }
}

// ---------- หน้าเพิ่มเติม ----------

@Composable
fun MoreScreen(vm: MainVm) {
    var confirmAdb by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.installUri(uri)
    }
    val on = vm.connected && !vm.busy
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("เพิ่มเติม", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        if (!vm.connected) Hint("เครื่องมือด้านล่างต้องเชื่อมต่อ ADB ก่อน (แท็บเริ่ม)")

        Panel {
            Title("ติดตั้งแอปลงโปรเจคเตอร์")
            FilledTonalButton(onClick = { picker.launch(arrayOf("*/*")) }, enabled = on) {
                Text("เลือกไฟล์ APK จากมือถือ")
            }
            OutlinedTextField(
                value = vm.url,
                onValueChange = { vm.url = it },
                label = { Text("หรือวางลิงก์ APK (https://...)") },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedButton(onClick = { vm.downloadInstall() }, enabled = on) { Text("ดาวน์โหลดแล้วติดตั้ง") }
        }

        Panel {
            Title("ความลื่น")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { vm.animations("0") }, enabled = on) { Text("ปิดแอนิเมชัน") }
                OutlinedButton(onClick = { vm.animations("0.5") }, enabled = on) { Text("0.5x") }
                OutlinedButton(onClick = { vm.animations("1.0") }, enabled = on) { Text("ปกติ") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { vm.trimCaches() }, enabled = on) { Text("ล้างแคช") }
                OutlinedButton(onClick = { vm.killBackground() }, enabled = on) { Text("เคลียร์แรม") }
            }
        }

        Panel {
            Title("หน้าหลัก (Launcher)")
            Hint("ตอนนี้: ${vm.home.ifBlank { "-" }}")
            TextButton(onClick = { vm.refreshHome() }, enabled = on) { Text("รีเฟรชรายการ") }
            vm.homes.forEach { c ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(c, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                    if (c == vm.home) Text("ใช้อยู่", fontSize = 12.sp, color = C.green)
                    else OutlinedButton(onClick = { vm.setHome(c) }, enabled = on) { Text("ตั้งเป็นหน้าหลัก") }
                }
            }
        }

        Panel {
            Title("ความปลอดภัย")
            Hint("เมื่อติดตั้ง Launcher แล้ว ควรปิด ADB เพื่อไม่ให้มีพอร์ตเปิดค้างในบ้าน")
            OutlinedButton(onClick = { confirmAdb = true }, enabled = on) { Text("ปิด ADB บนโปรเจคเตอร์") }
            LogBox(vm)
        }

        Panel {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(painterResource(R.drawable.ic_logo), contentDescription = null, modifier = Modifier.size(48.dp))
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("ProjectorTune 2.0", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text("สร้างโดย HAKIM", fontSize = 13.sp, color = C.gray)
                }
            }
            Hint(
                "แอปควบคุมและปรับแต่งโปรเจคเตอร์ Android ผ่าน Wi-Fi พร้อม Launcher สไตล์คลีน " +
                    "ได้แรงบันดาลใจจากโปรเจกต์ชุมชน เช่น ATV Optimizer, android-tv-makeover, " +
                    "Universal Android Debloater และไลบรารี dadb"
            )
        }
    }
    if (confirmAdb) {
        AlertDialog(
            onDismissRequest = { confirmAdb = false },
            containerColor = C.card2,
            title = { Text("ปิด ADB?") },
            text = { Text("ถ้าจะปรับแต่งด้วย ADB อีก ต้องไปเปิด USB debugging ใหม่ที่โปรเจคเตอร์ (การควบคุมไร้สายยังใช้ได้ตามปกติ)") },
            confirmButton = { TextButton(onClick = { vm.disableAdb(); confirmAdb = false }) { Text("ปิด") } },
            dismissButton = { TextButton(onClick = { confirmAdb = false }) { Text("ยกเลิก") } }
        )
    }
}
