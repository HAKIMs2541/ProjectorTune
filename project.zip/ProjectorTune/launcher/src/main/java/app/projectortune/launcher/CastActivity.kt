package app.projectortune.launcher

import android.app.Activity
import android.graphics.Color
import android.media.MediaCodec
import android.media.MediaFormat
import android.os.Bundle
import android.view.Gravity
import android.view.Surface
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.WindowManager
import android.widget.FrameLayout
import java.util.concurrent.TimeUnit

/** แสดงภาพที่สตรีมมาจากมือถือ */
class CastActivity : Activity(), Navigable, SurfaceHolder.Callback {
    @Volatile
    private var running = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        val sv = SurfaceView(this)
        val dm = resources.displayMetrics
        val sc = minOf(dm.widthPixels.toFloat() / Cast.w, dm.heightPixels.toFloat() / Cast.h)
        root.addView(
            sv,
            FrameLayout.LayoutParams((Cast.w * sc).toInt(), (Cast.h * sc).toInt(), Gravity.CENTER)
        )
        setContentView(root)
        sv.holder.addCallback(this)
    }

    override fun onResume() {
        super.onResume()
        Top.activity = this
    }

    override fun onPause() {
        if (Top.activity === this) Top.activity = null
        super.onPause()
    }

    override fun onDestroy() {
        running = false
        super.onDestroy()
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        running = true
        val surface = holder.surface
        Thread { decode(surface) }.start()
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        running = false
    }

    override fun nav(k: String): Boolean {
        if (k == "BACK" || k == "HOME") {
            Cast.stop()
            finish()
            return true
        }
        return false
    }

    private fun decode(surface: Surface) {
        var codec: MediaCodec? = null
        try {
            var waited = 0
            while (running && Cast.config == null && waited < 100) {
                Thread.sleep(50)
                waited++
            }
            val cfg = Cast.config ?: return
            val fmt = MediaFormat.createVideoFormat("video/avc", Cast.w, Cast.h)
            fmt.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 1024 * 1024)
            val c = MediaCodec.createDecoderByType("video/avc")
            codec = c
            c.configure(fmt, surface, null, 0)
            c.start()

            var idx = -1
            while (running && idx < 0) idx = c.dequeueInputBuffer(10000)
            if (idx >= 0) {
                val b = c.getInputBuffer(idx)!!
                b.clear()
                b.put(cfg)
                c.queueInputBuffer(idx, 0, cfg.size, 0, MediaCodec.BUFFER_FLAG_CODEC_CONFIG)
            }

            val info = MediaCodec.BufferInfo()
            var pts = 0L
            while (running && Cast.active) {
                val f = Cast.queue.poll(30, TimeUnit.MILLISECONDS)
                if (f != null) {
                    val i = c.dequeueInputBuffer(20000)
                    if (i >= 0) {
                        val b = c.getInputBuffer(i)!!
                        b.clear()
                        b.put(f)
                        c.queueInputBuffer(i, 0, f.size, pts, 0)
                        pts += 33333
                    }
                }
                var o = c.dequeueOutputBuffer(info, 0)
                while (o >= 0) {
                    c.releaseOutputBuffer(o, true)
                    o = c.dequeueOutputBuffer(info, 0)
                }
            }
        } catch (e: Throwable) {
        } finally {
            runCatching { codec?.stop() }
            runCatching { codec?.release() }
            if (!isFinishing) runOnUiThread { finish() }
        }
    }
}
