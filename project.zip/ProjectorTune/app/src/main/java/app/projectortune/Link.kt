package app.projectortune

import android.content.Context
import android.os.Build
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketTimeoutException
import java.util.concurrent.Executors

class TvApp(val pkg: String, val label: String, val hidden: Boolean)

/** การเชื่อมต่อไร้สายกับ Launcher บนโปรเจคเตอร์ (ไม่ใช้ ADB) */
object Link {
    class Found(val id: String, val name: String, val ip: String, val port: Int)

    var state by mutableStateOf("off") // off, connecting, on
    var tvName by mutableStateOf("")
    var tvIp by mutableStateOf("")
    var apps by mutableStateOf<List<TvApp>>(emptyList())
    var info by mutableStateOf("")
    var casting by mutableStateOf(false)
    var error by mutableStateOf("")

    private var prefs: android.content.SharedPreferences? = null

    @Volatile
    private var sock: Socket? = null

    @Volatile
    private var out: DataOutputStream? = null
    private val exec = Executors.newSingleThreadExecutor()

    fun init(ctx: Context) {
        if (prefs == null) prefs = ctx.applicationContext.getSharedPreferences("link", Context.MODE_PRIVATE)
    }

    fun lastIp(): String = prefs?.getString("lastIp", "") ?: ""

    fun tokenFor(id: String, ip: String): String? {
        val p = prefs ?: return null
        val a = if (id.isNotEmpty()) p.getString("tok_id_$id", null) else null
        return a ?: p.getString("tok_ip_$ip", null)
    }

    private fun remember(ip: String, id: String, token: String?) {
        val e = prefs?.edit() ?: return
        e.putString("lastIp", ip)
        if (token != null && token.isNotEmpty()) {
            e.putString("tok_ip_$ip", token)
            if (id.isNotEmpty()) e.putString("tok_id_$id", token)
        }
        e.apply()
    }

    suspend fun discover(): List<Found> = withContext(Dispatchers.IO) {
        val res = LinkedHashMap<String, Found>()
        try {
            DatagramSocket().use { s ->
                s.broadcast = true
                s.soTimeout = 400
                val msg = "PT_DISCOVER".toByteArray()
                val targets = ArrayList<String>()
                targets.add("255.255.255.255")
                localBase()?.let { targets.add("$it.255") }
                val last = lastIp()
                if (last.isNotEmpty()) targets.add(last)
                for (t in targets) {
                    try {
                        s.send(DatagramPacket(msg, msg.size, InetAddress.getByName(t), 40401))
                    } catch (e: Throwable) {
                    }
                }
                val end = System.currentTimeMillis() + 1500
                val buf = ByteArray(512)
                while (System.currentTimeMillis() < end) {
                    try {
                        val p = DatagramPacket(buf, buf.size)
                        s.receive(p)
                        val t = String(p.data, 0, p.length)
                        if (t.startsWith("PT_HERE|")) {
                            val parts = t.split("|")
                            val id = parts.getOrElse(1) { "" }
                            res[id] = Found(
                                id,
                                parts.getOrElse(2) { "?" },
                                p.address.hostAddress ?: "",
                                parts.getOrElse(3) { "40402" }.toIntOrNull() ?: 40402
                            )
                        }
                    } catch (e: SocketTimeoutException) {
                    }
                }
            }
        } catch (e: Throwable) {
        }
        res.values.toList()
    }

    suspend fun connect(ip: String, port: Int, token: String?, pin: String?): Boolean =
        withContext(Dispatchers.IO) {
            close()
            state = "connecting"
            error = ""
            try {
                val s = Socket()
                s.connect(InetSocketAddress(ip, port), 4000)
                s.tcpNoDelay = true
                s.soTimeout = 8000
                val i = DataInputStream(BufferedInputStream(s.getInputStream()))
                val o = DataOutputStream(BufferedOutputStream(s.getOutputStream()))
                val hello = JSONObject().put("t", "hello").put("name", Build.MODEL)
                if (token != null) hello.put("token", token)
                if (pin != null) hello.put("pin", pin)
                Proto.write(o, Proto.T_JSON, hello.toString().toByteArray())
                val r0 = Proto.read(i)
                val r = JSONObject(String(r0.second))
                if (r0.first != Proto.T_JSON || r.optString("t") != "ok") {
                    runCatching { s.close() }
                    error = r.optString("m", "ปฏิเสธการเชื่อมต่อ")
                    state = "off"
                    return@withContext false
                }
                s.soTimeout = 0
                sock = s
                out = o
                tvIp = ip
                tvName = r.optString("name")
                val nt = r.optString("token")
                remember(ip, r.optString("id"), if (nt.isNotEmpty()) nt else token)
                state = "on"
                val th = Thread { readLoop(i, s) }
                th.isDaemon = true
                th.start()
                send(JSONObject().put("t", "apps"))
                send(JSONObject().put("t", "info"))
                true
            } catch (e: Throwable) {
                error = e.message ?: "เชื่อมต่อไม่ได้"
                state = "off"
                false
            }
        }

    private fun readLoop(i: DataInputStream, s: Socket) {
        try {
            while (true) {
                val f = Proto.read(i)
                if (f.first == Proto.T_JSON) onMsg(JSONObject(String(f.second)))
            }
        } catch (e: Throwable) {
        }
        if (sock === s) {
            state = "off"
            casting = false
            sock = null
            out = null
        }
    }

    private fun onMsg(j: JSONObject) {
        when (j.optString("t")) {
            "apps" -> {
                val arr = j.optJSONArray("list")
                val l = ArrayList<TvApp>()
                if (arr != null) {
                    for (k in 0 until arr.length()) {
                        val a = arr.getJSONObject(k)
                        l.add(TvApp(a.optString("p"), a.optString("n"), a.optBoolean("h")))
                    }
                }
                apps = l
            }
            "info" -> info = j.optString("text")
        }
    }

    fun send(j: JSONObject) {
        exec.execute {
            try {
                val o = out
                if (o != null) Proto.write(o, Proto.T_JSON, j.toString().toByteArray())
            } catch (e: Throwable) {
            }
        }
    }

    /** ส่งเฟรมภาพ (เรียกจากเธรดเข้ารหัสวิดีโอ) */
    fun sendFrame(type: Int, data: ByteArray): Boolean {
        val o = out ?: return false
        return try {
            Proto.write(o, type, data)
            true
        } catch (e: Throwable) {
            false
        }
    }

    fun close() {
        runCatching { sock?.close() }
        sock = null
        out = null
        state = "off"
        casting = false
    }

    private fun cmd(t: String) = JSONObject().put("t", t)

    fun key(k: String) = send(cmd("key").put("k", k))
    fun tap(x: Float, y: Float) = send(cmd("tap").put("x", x.toDouble()).put("y", y.toDouble()))
    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float) = send(
        cmd("swipe").put("x1", x1.toDouble()).put("y1", y1.toDouble())
            .put("x2", x2.toDouble()).put("y2", y2.toDouble()).put("ms", 300)
    )

    fun vol(d: Int) = send(cmd("vol").put("d", d))
    fun launch(pkg: String) = send(cmd("launch").put("pkg", pkg))
    fun hide(pkg: String, on: Boolean) {
        send(cmd("hide").put("pkg", pkg).put("on", on))
        apps = apps.map { if (it.pkg == pkg) TvApp(it.pkg, it.label, on) else it }
    }

    fun play(url: String) = send(cmd("play").put("url", url))
    fun media(a: String, ms: Int = 0) = send(cmd("media").put("a", a).put("ms", ms))
    fun castStart(w: Int, h: Int) = send(cmd("cast_start").put("w", w).put("h", h))
    fun castStop() = send(cmd("cast_stop"))
    fun refreshApps() = send(cmd("apps"))
}
