package app.projectortune

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel

object C {
    val bg = Color(0xFF0B0D12)
    val card = Color(0xFF171A22)
    val card2 = Color(0xFF222733)
    val blue = Color(0xFF0A84FF)
    val green = Color(0xFF30D158)
    val orange = Color(0xFFFF9F0A)
    val red = Color(0xFFFF453A)
    val gray = Color(0xFF9A9AA2)
    val text = Color(0xFFF2F2F7)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AppTheme { Root() } }
    }
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = C.blue,
            background = C.bg,
            surface = C.card,
            onSurface = C.text,
            onBackground = C.text,
            surfaceVariant = C.card2
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = C.bg) { content() }
    }
}

@Composable
fun TabIcon(i: Int, color: Color) {
    Canvas(Modifier.size(24.dp)) {
        val w = size.width
        val h = size.height
        when (i) {
            0 -> {
                val p = Path()
                p.moveTo(w * 0.3f, h * 0.2f)
                p.lineTo(w * 0.8f, h * 0.5f)
                p.lineTo(w * 0.3f, h * 0.8f)
                p.close()
                drawPath(p, color)
            }
            1 -> {
                drawCircle(color, w * 0.42f, style = Stroke(w * 0.09f))
                drawCircle(color, w * 0.12f)
            }
            2 -> {
                val s = w * 0.36f
                val g = w * 0.1f
                listOf(Pair(0f, 0f), Pair(1f, 0f), Pair(0f, 1f), Pair(1f, 1f)).forEach { pr ->
                    drawRoundRect(
                        color,
                        Offset(g + pr.first * (s + g * 1.4f), g + pr.second * (s + g * 1.4f)),
                        Size(s, s),
                        CornerRadius(w * 0.08f),
                        style = Stroke(w * 0.08f)
                    )
                }
            }
            else -> {
                listOf(0.2f, 0.5f, 0.8f).forEach { x ->
                    drawCircle(color, w * 0.07f, Offset(w * x, h * 0.5f))
                }
            }
        }
    }
}

@Composable
fun Root(vm: MainVm = viewModel()) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val labels = listOf("เริ่ม", "ควบคุม", "แอป", "เพิ่มเติม")

    vm.dlg?.let { d ->
        AlertDialog(
            onDismissRequest = {},
            containerColor = C.card2,
            title = { Text(d.title) },
            text = { Text(d.text, fontSize = 14.sp) },
            confirmButton = {
                Column {
                    d.options.forEachIndexed { i, o ->
                        TextButton(onClick = { vm.answer(i) }) { Text(o) }
                    }
                    TextButton(onClick = { vm.answer(-1) }) { Text("ยกเลิก", color = C.gray) }
                }
            }
        )
    }

    Scaffold(
        containerColor = C.bg,
        bottomBar = {
            NavigationBar(containerColor = C.card) {
                labels.forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { TabIcon(i, if (tab == i) C.blue else C.gray) },
                        label = { Text(t, maxLines = 1, fontSize = 12.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedTextColor = C.blue,
                            unselectedTextColor = C.gray,
                            indicatorColor = C.card2
                        )
                    )
                }
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (vm.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            when (tab) {
                0 -> HomeScreen(vm)
                1 -> RemoteScreen(vm)
                2 -> AppsScreen(vm)
                else -> MoreScreen(vm)
            }
        }
    }
}
