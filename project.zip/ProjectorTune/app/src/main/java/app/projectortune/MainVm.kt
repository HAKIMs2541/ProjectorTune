package app.projectortune

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.URL
import java.security.SecureRandom

data class Pkg(val name: String, val system: Boolean, val disabled: Boolean)

enum class Risk { PROTECTED, SUSPECT, NORMAL }

enum class St { WAIT, RUN, OK, SKIP, FAIL }

data class Step(val name: String, val st: St = St.WAIT, val note: String = "")

/** กล่องถามผู้ใช้ระหว่างโหมดอัตโนมัติ (ตอบได้แค่ตัวเลือกที่ให้) */
class Dlg(val title: String, val text: String, val options: List<String>) {
    val answer = CompletableDeferred<Int>()
}

const val LAUNCHER_PKG = "app.projectortune.launcher"

class MainVm(app: Application) : AndroidViewModel(app) {
    private val adb = Adb(app)
    private val prefs = app.getSharedPreferences("changes", Context.MODE_PRIVATE)

    // --- ADB / ตั้งค่าครั้งแรก ---
    var host by mutableStateOf("")
    var status by mutableStateOf("ยังไม่ได้เชื่อมต่อ")
    var info by mutableStateOf("")
    var connected by mutableStateOf(false)
    var busy by mutableStateOf(false)
    var found by mutableStateOf<List<String>>(emptyList())
    var pkgs by mutableStateOf<List<Pkg>>(emptyList())
    var home by mutableStateOf("")
    var homes by mutableStateOf<List<String>>(emptyList())
    var log by mutableStateOf("")
    var query by mutableStateOf("")
    var showSystem by mutableStateOf(true)
    var url by mutableStateOf("")
    var steps by mutableStateOf<List<Step>>(emptyList())
    var dlg by mutableStateOf<Dlg?>(null)

    // --- ควบคุมไร้สาย ---
    var tvFound by mutableStateOf<List<Link.Found>>(emptyList())
    var tvMsg by mutableStateOf("")
    var pinFor by mutableStateOf<Link.Found?>(null)
    var pinInput by mutableStateOf("")
    var castUrl by mutableStateOf("")

    private val keep = HashSet<String>()

    private val nameRe = Regex("^[A-Za-z0-9._]+$")
    private val compRe = Regex("^[A-Za-z0-9._\$]+/[A-Za-z0-9._\$]+\$")

    // รายการแพ็กเกจที่ชุมชน (Universal Android Debloater) ระบุว่า "Recommended" ให้ปิดได้
    private val uadUrl =
        "https://raw.githubusercontent.com/0x192/universal-android-debloater/main/resources/assets/uad_lists.json"

    // แอปที่ห้ามปิดเด็ดขาด (กันเครื่องพัง)
    private val protectedExact = setOf(
        "android", "com.android.systemui", "com.android.settings", "com.android.shell",
        "com.android.packageinstaller", "com.google.android.packageinstaller",
        "com.android.inputdevices", "com.android.keychain", "com.android.certinstaller",
        "com.android.webview", "com.google.android.webview", "com.google.android.gms",
        "com.google.android.gsf", LAUNCHER_PKG
    )
    private val protectedPrefix = listOf(
        "com.android.providers.", "com.android.inputmethod", "com.android.bluetooth",
        "com.android.phone", "com.android.server.", "com.android.location",
        "com.android.documentsui", "com.android.externalstorage", "com.android.permissioncontroller"
    )
    // ชื่อที่น่าจะเกี่ยวกับฮาร์ดแวร์โปรเจคเตอร์ (คีย์สโตน โฟกัส รีโมต สัญญาณภาพ/เสียง)
    private val protectedWords = listOf(
        "keystone", "trapezoid", "focus", "projector", "hdmi", "tvinput", "tvsettings",
        "remote", "wifi", "bluetooth", "audio", "display", "mediatek", "mstar", "amlogic",
        "hisilicon", "rockchip", "allwinner", "sunxi", "realtek", "factory", "inputmethod"
    )
    // คำที่มักเป็นโฆษณา/ติดตาม (แค่ไฮไลต์ ไม่ปิดให้เอง)
    private val suspectWords = listOf(
        "adservice", "advert", "promo", "push", "analytics", "tracker", "statistic",
        "feedback", "marketing", "recommend", "hotapp", "appstore", "market", "campaign"
    )

    init {
        Link.init(app)
        autoReconnect()
    }

    private fun say(s: String) {
        log = (s + "\n" + log).take(4000)
    }

    private fun launchBusy(block: suspend () -> Unit) {
        viewModelScope.launch {
            busy = true
            try {
                block()
            } catch (e: Throwable) {
                say("ผิดพลาด: ${e.message ?: e.javaClass.simpleName}")
            } finally {
                busy = false
            }
        }
    }

    fun homePkg(): String = home.substringBefore('/')

    fun risk(n: String): Risk {
        if (n in protectedExact || n in keep || protectedPrefix.any { n.startsWith(it) } ||
            protectedWords.any { n.contains(it, true) } || n == homePkg()
        ) return Risk.PROTECTED
        val segs = n.lowercase().split('.')
        if (segs.any { s -> s == "ad" || s == "ads" || suspectWords.any { s.contains(it) } }) return Risk.SUSPECT
        return Risk.NORMAL
    }

    // ---------- เชื่อมต่อ ADB ----------
    fun scan() = launchBusy {
        status = "กำลังสแกนหาโปรเจคเตอร์ในวง Wi-Fi..."
        found = adb.scan()
        status = if (found.isEmpty()) "ไม่พบเครื่อง (เช็กว่าเปิด USB debugging แล้ว และอยู่ Wi-Fi เดียวกัน)"
        else "พบ ${found.size} เครื่อง แตะที่ IP เพื่อเลือก"
        if (host.isBlank()) found.firstOrNull()?.let { host = it }
    }

    fun connect() = launchBusy {
        val h = host.trim()
        if (h.isEmpty()) {
            status = "กรอก IP ของโปรเจคเตอร์ก่อน"
            return@launchBusy
        }
        status = "กำลังเชื่อมต่อ... ดูหน้าจอโปรเจคเตอร์แล้วกด 'อนุญาต'"
        try {
            adb.connect(h)
        } catch (e: Throwable) {
            connected = false
            status = "เชื่อมต่อไม่สำเร็จ: ${e.message ?: e.javaClass.simpleName}"
            return@launchBusy
        }
        connected = true
        status = "เชื่อมต่อแล้ว ($h)"
        loadInfo()
        loadHome()
    }

    fun disconnect() {
        adb.close()
        connected = false
        pkgs = emptyList()
        status = "ตัดการเชื่อมต่อแล้ว"
    }

    private suspend fun loadInfo() {
        val model = adb.sh("getprop ro.product.model").trim()
        val ver = adb.sh("getprop ro.build.version.release").trim()
        val mem = adb.sh("grep -E 'MemTotal|MemAvailable' /proc/meminfo").trim()
        info = "รุ่น $model · Android $ver\n$mem"
    }

    private suspend fun loadHome() {
        val cmd = "-a android.intent.action.MAIN -c android.intent.category.HOME"
        homes = adb.sh("cmd package query-activities --brief $cmd").lines()
            .map { it.trim() }.filter { compRe.matches(it) }.distinct()
        home = adb.sh("cmd package resolve-activity --brief $cmd").lines()
            .map { it.trim() }.lastOrNull { compRe.matches(it) } ?: ""
    }

    fun refreshHome() = launchBusy { loadHome() }

    // ---------- แอป ----------
    private fun names(out: String) =
        out.lines().map { it.trim().removePrefix("package:") }.filter { it.isNotBlank() && nameRe.matches(it) }

    private suspend fun refreshPkgs() {
        val all = names(adb.sh("pm list packages"))
        val dis = names(adb.sh("pm list packages -d")).toSet()
        val sys = names(adb.sh("pm list packages -s")).toSet()
        pkgs = all.map { Pkg(it, it in sys, it in dis) }.sortedBy { it.name }
    }

    fun loadPackages() = launchBusy {
        refreshPkgs()
        loadHome()
        say("โหลดรายชื่อแอป ${pkgs.size} รายการ")
    }

    private fun changed(): MutableSet<String> =
        prefs.getStringSet("disabled", emptySet())!!.toMutableSet()

    fun toggle(p: Pkg) = launchBusy {
        if (!nameRe.matches(p.name)) return@launchBusy
        if (risk(p.name) == Risk.PROTECTED) {
            say("${p.name}: เป็นแอปสำคัญ ห้ามปิด")
            return@launchBusy
        }
        val cmd = if (p.disabled) "pm enable ${p.name}" else "pm disable-user --user 0 ${p.name}"
        val out = adb.sh(cmd).trim()
        say("${p.name}: $out")
        if (out.contains("new state", true)) {
            val s = changed()
            if (p.disabled) s.remove(p.name) else s.add(p.name)
            prefs.edit().putStringSet("disabled", s).apply()
            pkgs = pkgs.map { if (it.name == p.name) it.copy(disabled = !p.disabled) else it }
        }
    }

    private suspend fun restoreNow(): Int {
        val s = changed()
        var n = 0
        for (name in s.toList()) {
            if (!nameRe.matches(name)) continue
            say("$name: ${adb.sh("pm enable $name").trim()}")
            s.remove(name)
            n++
        }
        prefs.edit().putStringSet("disabled", s).apply()
        pkgs = pkgs.map { it.copy(disabled = false) }
        return n
    }

    fun restoreAll() = launchBusy {
        if (restoreNow() == 0) say("ไม่มีแอปที่แอปนี้เคยปิดไว้")
    }

    // ---------- ติดตั้งไฟล์ ----------
    private suspend fun copyUri(uri: Uri): File = withContext(Dispatchers.IO) {
        val f = File(getApplication<Application>().cacheDir, "pick.apk")
        getApplication<Application>().contentResolver.openInputStream(uri)!!.use { i ->
            f.outputStream().use { o -> i.copyTo(o) }
        }
        f
    }

    private suspend fun download(u: String, name: String): File = withContext(Dispatchers.IO) {
        val f = File(getApplication<Application>().cacheDir, name)
        val c = URL(u).openConnection()
        c.connectTimeout = 10000
        c.readTimeout = 30000
        c.getInputStream().use { i -> f.outputStream().use { o -> i.copyTo(o) } }
        f
    }

    fun installUri(uri: Uri) = launchBusy {
        say("กำลังคัดลอกไฟล์...")
        val f = copyUri(uri)
        say("กำลังติดตั้งลงโปรเจคเตอร์...")
        say(runCatching { adb.install(f) }.getOrElse { "ติดตั้งไม่สำเร็จ: ${it.message}" })
    }

    fun downloadInstall() = launchBusy {
        val u = url.trim()
        if (!u.startsWith("https://")) {
            say("ใช้ได้เฉพาะลิงก์ https://")
            return@launchBusy
        }
        say("กำลังดาวน์โหลด...")
        val f = download(u, "dl.apk")
        say("กำลังติดตั้งลงโปรเจคเตอร์...")
        say(runCatching { adb.install(f) }.getOrElse { "ติดตั้งไม่สำเร็จ: ${it.message}" })
    }

    // ---------- ปรับแต่ง ----------
    fun animations(scale: String) = launchBusy {
        applyAnimations(scale)
        say("ตั้งแอนิเมชันเป็น ${scale}x แล้ว")
    }

    private suspend fun applyAnimations(scale: String) {
        if (scale !in setOf("0", "0.5", "1.0")) return
        for (k in listOf("window_animation_scale", "transition_animation_scale", "animator_duration_scale")) {
            adb.sh("settings put global $k $scale")
        }
    }

    fun trimCaches() = launchBusy {
        adb.sh("pm trim-caches 999G")
        say("ล้างแคชแล้ว")
    }

    fun killBackground() = launchBusy {
        adb.sh("am kill-all")
        say("ปิดแอปเบื้องหลังแล้ว")
        loadInfo()
    }

    fun setHome(comp: String) = launchBusy {
        if (!compRe.matches(comp)) return@launchBusy
        val out = adb.sh("cmd package set-home-activity '$comp'").trim()
        say("ตั้งหน้าหลัก $comp: ${out.ifBlank { "สำเร็จ" }}")
        loadHome()
    }

    private suspend fun adbOff() {
        say("ปิด ADB บนโปรเจคเตอร์ (เปิดใหม่ได้ที่ Developer options)")
        runCatching { adb.sh("settings put global adb_enabled 0") }
        adb.close()
        connected = false
        pkgs = emptyList()
        status = "ปิด ADB แล้ว"
    }

    fun disableAdb() = launchBusy { adbOff() }

    // ---------- ควบคุมไร้สาย (ไม่ใช้ ADB) ----------
    private fun autoReconnect() {
        viewModelScope.launch {
            val ip = Link.lastIp()
            val tok = Link.tokenFor("", ip)
            if (ip.isNotEmpty() && tok != null) Link.connect(ip, 40402, tok, null)
        }
    }

    fun discoverTv() = launchBusy {
        tvMsg = "กำลังค้นหา Launcher ในวง Wi-Fi..."
        tvFound = Link.discover()
        tvMsg = if (tvFound.isEmpty()) {
            "ไม่พบ ลองกด 'เริ่มปรับแต่งอัตโนมัติ' ที่แท็บเริ่มก่อน หรือเช็กว่าอยู่ Wi-Fi เดียวกัน"
        } else {
            "พบ ${tvFound.size} เครื่อง"
        }
    }

    fun pickTv(f: Link.Found) = launchBusy {
        val tok = Link.tokenFor(f.id, f.ip)
        if (tok != null && Link.connect(f.ip, f.port, tok, null)) {
            tvMsg = ""
            return@launchBusy
        }
        pinFor = f
    }

    fun submitPin() = launchBusy {
        val f = pinFor ?: return@launchBusy
        if (Link.connect(f.ip, f.port, null, pinInput.trim())) {
            pinFor = null
            pinInput = ""
            tvMsg = ""
        } else {
            tvMsg = Link.error
        }
    }

    fun tvDisconnect() {
        castStop()
        Link.close()
    }

    fun castStart(code: Int, data: Intent) = launchBusy {
        val app = getApplication<Application>()
        val sz = CastService.size(app)
        Link.castStart(sz.first, sz.second)
        delay(400)
        CastService.start(app, code, data, sz.first, sz.second, sz.third)
        Link.casting = true
    }

    fun castStop() {
        Link.castStop()
        CastService.stop(getApplication())
        Link.casting = false
    }

    fun playUrl() {
        val u = castUrl.trim()
        if (u.startsWith("http://") || u.startsWith("https://")) Link.play(u)
    }

    // ---------- โหมดอัตโนมัติ ----------
    private suspend fun ask(title: String, text: String, options: List<String>): Int {
        val d = Dlg(title, text, options)
        dlg = d
        val a = d.answer.await()
        dlg = null
        return a
    }

    fun answer(i: Int) {
        dlg?.answer?.complete(i)
    }

    private fun setStep(i: Int, st: St, note: String = "") {
        steps = steps.mapIndexed { k, s -> if (k == i) s.copy(st = st, note = note) else s }
    }

    private suspend fun communityList(installed: List<Pkg>): List<String> = withContext(Dispatchers.IO) {
        try {
            val c = URL(uadUrl).openConnection()
            c.connectTimeout = 10000
            c.readTimeout = 40000
            val o = JSONObject(c.getInputStream().bufferedReader().use { it.readText() })
            installed.filter {
                !it.disabled && o.has(it.name) &&
                    o.optJSONObject(it.name)?.optString("removal") == "Recommended"
            }.map { it.name }.filter { risk(it) != Risk.PROTECTED }
        } catch (e: Throwable) {
            emptyList()
        }
    }

    private suspend fun launcherApk(): File? = withContext(Dispatchers.IO) {
        try {
            val f = File(getApplication<Application>().cacheDir, "launcher.apk")
            getApplication<Application>().assets.open("launcher.apk").use { i ->
                f.outputStream().use { o -> i.copyTo(o) }
            }
            f
        } catch (e: Throwable) {
            null
        }
    }

    private fun newToken(): String {
        val b = ByteArray(16)
        SecureRandom().nextBytes(b)
        return b.joinToString("") { "%02x".format(it) }
    }

    fun startAuto() = launchBusy {
        steps = listOf(
            "เชื่อมต่อโปรเจคเตอร์ (ADB ครั้งแรก)", "ตรวจสอบเครื่อง", "ปรับความลื่น",
            "ติดตั้ง Launcher ของ ProjectorTune", "ปิดแอปโฆษณา/ขยะ", "ล้างแคชและแรม",
            "เชื่อมต่อไร้สาย (ไม่ใช้ ADB)", "ตรวจความปลอดภัย"
        ).map { Step(it) }

        // 0) เชื่อมต่อ ADB (ผู้ใช้แค่กดอนุญาตบนโปรเจคเตอร์)
        setStep(0, St.RUN, "กำลังหาเครื่อง...")
        if (!connected) {
            if (host.isBlank()) {
                found = adb.scan()
                when {
                    found.isEmpty() -> {
                        setStep(0, St.FAIL, "ไม่พบโปรเจคเตอร์ เปิด USB debugging แล้วลองใหม่ หรือกรอก IP เอง")
                        return@launchBusy
                    }
                    found.size == 1 -> host = found[0]
                    else -> {
                        val i = ask("เจอหลายเครื่อง", "เลือกเครื่องที่ต้องการปรับแต่ง", found)
                        if (i < 0 || i >= found.size) {
                            setStep(0, St.SKIP, "ยกเลิก")
                            return@launchBusy
                        }
                        host = found[i]
                    }
                }
            }
            setStep(0, St.RUN, "กดอนุญาตบนหน้าจอโปรเจคเตอร์")
            try {
                adb.connect(host.trim())
            } catch (e: Throwable) {
                setStep(0, St.FAIL, e.message ?: "เชื่อมต่อไม่ได้")
                return@launchBusy
            }
            connected = true
        }
        status = "เชื่อมต่อแล้ว ($host)"
        setStep(0, St.OK, host)

        // 1) ตรวจเครื่อง + วางแผน
        setStep(1, St.RUN)
        loadInfo()
        loadHome()
        keep.add(homePkg())
        refreshPkgs()
        val community = communityList(pkgs)
        val suspects = pkgs.filter {
            it.system && !it.disabled && it.name !in community && risk(it.name) == Risk.SUSPECT
        }.map { it.name }
        setStep(1, St.OK, info.lineSequence().firstOrNull() ?: "")

        val preview = (community + suspects).take(6).joinToString("\n")
        val choice = ask(
            "พร้อมปรับแต่งอัตโนมัติ",
            "จะติดตั้ง Launcher ของ ProjectorTune เป็นหน้าหลัก (สไตล์คลีน ไม่มีโฆษณา)\n" +
                "แอปที่ชุมชนแนะนำให้ปิด: ${community.size} ตัว\nแอปชื่อน่าสงสัย: ${suspects.size} ตัว\n" +
                "ทุกอย่างย้อนกลับได้ และแอปสำคัญถูกล็อกไว้\n\nตัวอย่าง:\n$preview",
            listOf("เริ่มเลย (แนะนำ)", "เริ่ม + ปิดแอปชื่อน่าสงสัยด้วย")
        )
        if (choice !in 0..1) {
            for (i in 2 until steps.size) setStep(i, St.SKIP, "ยกเลิก")
            return@launchBusy
        }

        // 2) ความลื่น
        setStep(2, St.RUN)
        applyAnimations("0.5")
        setStep(2, St.OK, "แอนิเมชัน 0.5x")

        // 3) ติดตั้ง Launcher ที่ฝังมากับแอป แล้วมอบสิทธิ์ให้ควบคุมไร้สายได้
        setStep(3, St.RUN)
        val token = newToken()
        var installed = false
        val apk = launcherApk()
        if (apk == null) {
            setStep(3, St.FAIL, "ไม่พบไฟล์ Launcher ในแอป (บิลด์ไม่สมบูรณ์)")
        } else {
            try {
                adb.install(apk)
                adb.sh("pm grant $LAUNCHER_PKG android.permission.WRITE_SECURE_SETTINGS")
                adb.sh("appops set $LAUNCHER_PKG SYSTEM_ALERT_WINDOW allow")
                runCatching { adb.sh("dumpsys deviceidle whitelist +$LAUNCHER_PKG") }
                adb.sh("cmd package set-home-activity $LAUNCHER_PKG/.HomeActivity")
                adb.sh("am start -n $LAUNCHER_PKG/.HomeActivity --es pt_token $token")
                installed = true
                setStep(3, St.OK, "ตั้งเป็นหน้าหลักแล้ว")
            } catch (e: Throwable) {
                setStep(3, St.FAIL, e.message ?: "ติดตั้งไม่สำเร็จ")
            }
        }
        loadHome()

        // 4) ปิดแอปขยะ
        setStep(4, St.RUN)
        val targets = if (choice == 1) community + suspects else community
        val done = mutableListOf<String>()
        for ((k, p) in targets.withIndex()) {
            if (!nameRe.matches(p) || risk(p) == Risk.PROTECTED) continue
            val out = runCatching { adb.sh("pm disable-user --user 0 $p") }.getOrDefault("")
            if (out.contains("new state", true)) done.add(p)
            if (k % 5 == 0) setStep(4, St.RUN, "${k + 1}/${targets.size}")
        }
        val s = changed()
        s.addAll(done)
        prefs.edit().putStringSet("disabled", s).apply()
        setStep(4, St.OK, "ปิดแล้ว ${done.size} ตัว")

        // 5) แคช + แรม
        setStep(5, St.RUN)
        runCatching { adb.sh("pm trim-caches 999G") }
        runCatching { adb.sh("am kill-all") }
        runCatching { adb.sh("am start -n $LAUNCHER_PKG/.HomeActivity") }
        setStep(5, St.OK)

        // 6) เชื่อมต่อไร้สายกับ Launcher
        setStep(6, St.RUN)
        var wireless = false
        if (installed) {
            for (k in 1..15) {
                wireless = Link.connect(host.trim(), 40402, token, null)
                if (wireless) break
                delay(1000)
            }
            setStep(
                6, if (wireless) St.OK else St.FAIL,
                if (wireless) "พร้อมควบคุมโดยไม่ต้องใช้ ADB" else "ยังเชื่อมต่อไม่ได้ ลองที่แท็บควบคุม"
            )
        } else {
            setStep(6, St.SKIP, "ไม่ได้ติดตั้ง Launcher")
        }

        // 7) ตรวจความปลอดภัย: ถ้าหน้าหลักหาย ย้อนกลับทันที
        setStep(7, St.RUN)
        loadHome()
        if (home.isBlank()) {
            val n = restoreNow()
            loadHome()
            setStep(7, St.FAIL, "หน้าหลักผิดปกติ จึงเปิดแอปคืน $n ตัวอัตโนมัติ")
        } else {
            setStep(7, St.OK, "หน้าหลัก: ${homePkg()}")
        }
        refreshPkgs()
        loadInfo()

        val fin = ask(
            "เสร็จแล้ว",
            if (wireless) {
                "ต่อไปควบคุมและฉายหน้าจอได้ที่แท็บ 'ควบคุม' โดยไม่ต้องใช้ ADB\nแนะนำให้ปิด ADB เพื่อความปลอดภัย"
            } else {
                "ถ้าเครื่องมีอาการแปลก ใช้ 'กู้คืนทั้งหมด' ที่แท็บแอปได้"
            },
            listOf("ปิด ADB เลย (แนะนำ)", "ไว้ก่อน")
        )
        if (fin == 0) adbOff()
    }

    override fun onCleared() {
        adb.close()
    }
}
