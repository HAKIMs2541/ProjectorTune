package app.projectortune.launcher

import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.IOException

/** รูปแบบข้อมูลระหว่างมือถือกับ Launcher: [type:1][length:4][payload] */
object Proto {
    const val T_JSON = 1
    const val T_CONFIG = 2
    const val T_VIDEO = 3

    fun write(out: DataOutputStream, type: Int, data: ByteArray) {
        synchronized(out) {
            out.writeByte(type)
            out.writeInt(data.size)
            out.write(data)
            out.flush()
        }
    }

    fun read(inp: DataInputStream): Pair<Int, ByteArray> {
        val t = inp.readUnsignedByte()
        val n = inp.readInt()
        if (n < 0 || n > 8_000_000) throw IOException("bad frame")
        val b = ByteArray(n)
        inp.readFully(b)
        return Pair(t, b)
    }
}
