plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

// ฝัง APK ของ Launcher (โมดูล :launcher) ไว้ใน assets เพื่อให้แอปติดตั้งลงโปรเจคเตอร์เอง
val launcherApk = project(":launcher").layout.buildDirectory.file("outputs/apk/debug/launcher-debug.apk")
val launcherAssets = layout.buildDirectory.dir("generated/launcherAssets")
val copyLauncher = tasks.register<Copy>("copyLauncherApk") {
    dependsOn(":launcher:assembleDebug")
    from(launcherApk)
    into(launcherAssets)
    rename { "launcher.apk" }
}

android {
    namespace = "app.projectortune"
    compileSdk = 35

    defaultConfig {
        applicationId = "app.projectortune"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "2.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    sourceSets {
        getByName("main") {
            assets.srcDir(launcherAssets)
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
    packaging {
        resources {
            excludes += setOf(
                "/META-INF/{AL2.0,LGPL2.1}",
                "META-INF/INDEX.LIST",
                "META-INF/DEPENDENCIES",
                "META-INF/*.kotlin_module"
            )
        }
    }
}

tasks.matching { it.name.startsWith("merge") && it.name.endsWith("Assets") }.configureEach {
    dependsOn(copyLauncher)
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.10.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("dev.mobile:dadb:1.2.10")
}
