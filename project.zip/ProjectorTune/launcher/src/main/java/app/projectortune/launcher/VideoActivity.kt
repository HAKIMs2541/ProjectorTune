package app.projectortune.launcher

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.VideoView

/** เล่นวิดีโอจากลิงก์ที่มือถือส่งมา */
class VideoActivity : Activity(), Navigable {
    companion object {
        fun start(c: Context, url: String) {
            val i = Intent(c, VideoActivity::class.java)
            i.putExtra("url", url)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            c.startActivity(i)
        }

        fun control(a: String, ms: Int) {
            Handler(Looper.getMainLooper()).post {
                (Top.activity as? VideoActivity)?.doAction(a, ms)
            }
        }
    }

    private lateinit var vv: VideoView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        vv = VideoView(this)
        root.addView(
            vv,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER
            )
        )
        setContentView(root)
        vv.setOnPreparedListener { it.start() }
        vv.setOnCompletionListener { finish() }
        vv.setOnErrorListener { _, _, _ ->
            finish()
            true
        }
        play(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        play(intent)
    }

    private fun play(i: Intent?) {
        val u = i?.getStringExtra("url") ?: return
        vv.setVideoURI(Uri.parse(u))
    }

    override fun onResume() {
        super.onResume()
        Top.activity = this
    }

    override fun onPause() {
        if (Top.activity === this) Top.activity = null
        super.onPause()
    }

    fun doAction(a: String, ms: Int) {
        when (a) {
            "pause" -> vv.pause()
            "play" -> vv.start()
            "toggle" -> if (vv.isPlaying) vv.pause() else vv.start()
            "seek" -> vv.seekTo(maxOf(0, vv.currentPosition + ms))
            "stop" -> finish()
        }
    }

    override fun nav(k: String): Boolean {
        when (k) {
            "OK" -> doAction("toggle", 0)
            "LEFT" -> doAction("seek", -10000)
            "RIGHT" -> doAction("seek", 10000)
            "BACK", "HOME" -> finish()
            else -> return false
        }
        return true
    }
}
