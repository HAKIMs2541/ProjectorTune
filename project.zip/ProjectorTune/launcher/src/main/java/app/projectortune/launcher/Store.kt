package app.projectortune.launcher

import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable
import android.os.Handler
import android.os.Looper
import java.net.Inet4Address
import java.net.NetworkInterface
import java.security.SecureRandom
import java.util.UUID
import java.util.concurrent.LinkedBlockingQueue

/** หน้าจอที่รับคำสั่งปุ่มจากมือถือได้ */
interface Navigable {
    fun nav(k: String): Boolean
}

object Top {
    @Volatile
    var activity: Activity? = null
}

class AppItem(val pkg: String, val cls: String, val label: String, val icon: Drawable?)

object Store {
    private fun sp(c: Context) = c.getSharedPreferences("pt", Context.MODE_PRIVATE)

    fun deviceId(c: Context): String {
        val s = sp(c)
        val old = s.getString("id", null)
        if (old != null) return old
        val id = UUID.randomUUID().toString().replace("-", "").take(12)
        s.edit().putString("id", id).apply()
        return id
    }

    fun tokens(c: Context): Set<String> =
        HashSet<String>(sp(c).getStringSet("tokens", emptySet()) ?: emptySet())

    fun addToken(c: Context, t: String) {
        val s = HashSet<String>(tokens(c))
        s.add(t)
        sp(c).edit().putStringSet("tokens", s).apply()
    }

    fun hidden(c: Context): Set<String> =
        HashSet<String>(sp(c).getStringSet("hidden", emptySet()) ?: emptySet())

    fun setHidden(c: Context, pkg: String, on: Boolean) {
        val s = HashSet<String>(hidden(c))
        if (on) s.add(pkg) else s.remove(pkg)
        sp(c).edit().putStringSet("hidden", s).apply()
    }

    fun randomHex(n: Int): String {
        val b = ByteArray(n)
        SecureRandom().nextBytes(b)
        return b.joinToString("") { "%02x".format(it) }
    }

    fun pin(c: Context): String = sp(c).getString("pin", null) ?: newPin(c)

    fun newPin(c: Context): String {
        val p = (1000 + SecureRandom().nextInt(9000)).toString()
        sp(c).edit().putString("pin", p).apply()
        return p
    }
}

object Apps {
    fun list(c: Context, includeHidden: Boolean = false): List<AppItem> {
        val pm = c.packageManager
        val hidden = Store.hidden(c)
        val out = LinkedHashMap<String, AppItem>()
        for (cat in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            val q = Intent(Intent.ACTION_MAIN).addCategory(cat)
            for (ri in pm.queryIntentActivities(q, 0)) {
                val pkg = ri.activityInfo.packageName
                if (pkg == c.packageName || out.containsKey(pkg)) continue
                if (!includeHidden && pkg in hidden) continue
                out[pkg] = AppItem(
                    pkg,
                    ri.activityInfo.name,
                    ri.loadLabel(pm).toString(),
                    if (includeHidden) null else ri.loadIcon(pm)
                )
            }
        }
        return out.values.sortedBy { it.label.lowercase() }
    }

    fun launch(c: Context, pkg: String, cls: String? = null) {
        try {
            val i = if (cls != null) {
                Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                    .setComponent(ComponentName(pkg, cls))
            } else {
                c.packageManager.getLaunchIntentForPackage(pkg)
            }
            if (i != null) {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
                c.startActivity(i)
            }
        } catch (e: Throwable) {
        }
    }
}

object Net {
    fun localIp(): String {
        try {
            val ifaces = NetworkInterface.getNetworkInterfaces() ?: return "-"
            for (n in ifaces) {
                if (!n.isUp || n.isLoopback) continue
                for (a in n.inetAddresses) {
                    if (a is Inet4Address && a.isSiteLocalAddress) return a.hostAddress ?: "-"
                }
            }
        } catch (e: Throwable) {
        }
        return "-"
    }
}

/** ตัวกลางส่งภาพสตรีมจากเครือข่ายไปยังตัวถอดรหัสใน CastActivity */
object Cast {
    @Volatile
    var w = 1280

    @Volatile
    var h = 720

    @Volatile
    var config: ByteArray? = null

    @Volatile
    var active = false

    val queue = LinkedBlockingQueue<ByteArray>(90)

    fun start(w: Int, h: Int) {
        this.w = w
        this.h = h
        config = null
        queue.clear()
        active = true
    }

    fun stop() {
        active = false
        queue.clear()
    }

    fun offer(b: ByteArray) {
        if (!active) return
        if (!queue.offer(b)) {
            queue.clear()
            queue.offer(b)
        }
    }
}

object Remote {
    private val ui = Handler(Looper.getMainLooper())

    fun key(c: Context, k: String) {
        ui.post {
            val nav = Top.activity as? Navigable
            if (nav != null && nav.nav(k)) return@post
            when (k) {
                "HOME" -> {
                    val i = Intent(c, HomeActivity::class.java)
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    c.startActivity(i)
                }
                "BACK" -> TuneAccessibilityService.instance?.back()
            }
        }
    }
}
