package app.projectortune

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaCodec
import android.media.MediaFormat
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.WindowManager

/** จับภาพหน้าจอมือถือ เข้ารหัส H.264 แล้วส่งไปที่ Launcher บนโปรเจคเตอร์ */
class CastService : Service() {
    companion object {
        fun size(ctx: Context): Triple<Int, Int, Int> {
            val dm = DisplayMetrics()
            val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            wm.defaultDisplay.getRealMetrics(dm)
            val longSide = maxOf(dm.widthPixels, dm.heightPixels).toDouble()
            val s = minOf(1.0, 1280.0 / longSide)
            val w = maxOf(16, Math.round(dm.widthPixels * s / 16.0).toInt() * 16)
            val h = maxOf(16, Math.round(dm.heightPixels * s / 16.0).toInt() * 16)
            return Triple(w, h, dm.densityDpi)
        }

        fun start(c: Context, code: Int, data: Intent, w: Int, h: Int, dpi: Int) {
            val i = Intent(c, CastService::class.java)
            i.putExtra("code", code)
            i.putExtra("data", data)
            i.putExtra("w", w)
            i.putExtra("h", h)
            i.putExtra("dpi", dpi)
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i) else c.startService(i)
        }

        fun stop(c: Context) {
            c.stopService(Intent(c, CastService::class.java))
        }
    }

    @Volatile
    private var live = false
    private var projection: MediaProjection? = null
    private var encoder: MediaCodec? = null
    private var display: VirtualDisplay? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        startFg()
        try {
            val code = intent.getIntExtra("code", 0)
            @Suppress("DEPRECATION")
            val data = intent.getParcelableExtra<Intent>("data")
            val w = intent.getIntExtra("w", 1280)
            val h = intent.getIntExtra("h", 720)
            val dpi = intent.getIntExtra("dpi", 320)
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val proj = mpm.getMediaProjection(code, data!!)
            projection = proj
            begin(proj, w, h, dpi)
        } catch (e: Throwable) {
            Link.casting = false
            stopCast()
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startFg() {
        val b: Notification.Builder
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel("cast", "ProjectorTune Cast", NotificationManager.IMPORTANCE_LOW)
            )
            b = Notification.Builder(this, "cast")
        } else {
            b = Notification.Builder(this)
        }
        val n = b.setContentTitle("กำลังฉายหน้าจอไปที่โปรเจคเตอร์")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(2, n)
        }
    }

    private fun begin(proj: MediaProjection, w: Int, h: Int, dpi: Int) {
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                Link.castStop()
                Link.casting = false
                stopCast()
                stopSelf()
            }
        }, Handler(Looper.getMainLooper()))

        val fmt = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h)
        fmt.setInteger(
            MediaFormat.KEY_COLOR_FORMAT,
            android.media.MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface
        )
        fmt.setInteger(MediaFormat.KEY_BIT_RATE, 4_000_000)
        fmt.setInteger(MediaFormat.KEY_FRAME_RATE, 30)
        fmt.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        fmt.setLong(MediaFormat.KEY_REPEAT_PREVIOUS_FRAME_AFTER, 100_000L)
        val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        encoder = enc
        enc.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        val surf = enc.createInputSurface()
        enc.start()
        display = proj.createVirtualDisplay(
            "ProjectorTune", w, h, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, surf, null, null
        )
        live = true
        val t = Thread { drain(enc) }
        t.isDaemon = true
        t.start()
    }

    private fun drain(enc: MediaCodec) {
        val info = MediaCodec.BufferInfo()
        try {
            while (live) {
                val i = enc.dequeueOutputBuffer(info, 100_000)
                if (i >= 0) {
                    val b = enc.getOutputBuffer(i)
                    if (b != null && info.size > 0) {
                        val arr = ByteArray(info.size)
                        b.position(info.offset)
                        b.limit(info.offset + info.size)
                        b.get(arr)
                        val isConfig = (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0
                        val type = if (isConfig) Proto.T_CONFIG else Proto.T_VIDEO
                        if (!Link.sendFrame(type, arr)) live = false
                    }
                    enc.releaseOutputBuffer(i, false)
                }
            }
        } catch (e: Throwable) {
        }
        if (Link.casting) {
            Link.casting = false
            Handler(Looper.getMainLooper()).post { stopSelf() }
        }
    }

    private fun stopCast() {
        live = false
        runCatching { display?.release() }
        runCatching { encoder?.stop() }
        runCatching { encoder?.release() }
        runCatching { projection?.stop() }
        display = null
        encoder = null
        projection = null
    }

    override fun onDestroy() {
        stopCast()
        super.onDestroy()
    }
}
