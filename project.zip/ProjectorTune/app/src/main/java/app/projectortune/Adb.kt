package app.projectortune

import android.content.Context
import dadb.AdbKeyPair
import dadb.Dadb
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import java.io.File
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.Socket

/** สามฐานของ IP ในวง Wi-Fi เช่น 192.168.1 */
fun localBase(): String? {
    val ifaces = NetworkInterface.getNetworkInterfaces() ?: return null
    for (n in ifaces) {
        if (!n.isUp || n.isLoopback) continue
        for (a in n.inetAddresses) {
            if (a is Inet4Address && a.isSiteLocalAddress) {
                val p = a.hostAddress?.split(".") ?: continue
                if (p.size == 4) return p.take(3).joinToString(".")
            }
        }
    }
    return null
}

/** ตัวต่อ ADB ผ่าน Wi-Fi ใช้ครั้งแรกตอนติดตั้ง Launcher เท่านั้น (ไลบรารี dadb) */
class Adb(private val ctx: Context) {
    private var dadb: Dadb? = null

    private fun keys(): AdbKeyPair {
        val priv = File(ctx.filesDir, "adbkey")
        val pub = File(ctx.filesDir, "adbkey.pub")
        if (!priv.exists() || !pub.exists()) AdbKeyPair.generate(priv, pub)
        return AdbKeyPair.read(priv, pub)
    }

    suspend fun connect(host: String, port: Int = 5555) = withContext(Dispatchers.IO) {
        close()
        // เช็กว่าพอร์ตเปิดอยู่ก่อน (กันค้างนาน)
        Socket().use { it.connect(InetSocketAddress(host, port), 3000) }
        val d = Dadb.create(host, port, keys())
        try {
            // จุดนี้โปรเจคเตอร์จะถามว่า "Allow USB debugging?" ให้กดอนุญาต
            d.shell("echo ok")
        } catch (e: Throwable) {
            runCatching { d.close() }
            throw e
        }
        dadb = d
    }

    suspend fun sh(cmd: String): String = withContext(Dispatchers.IO) {
        val d = dadb ?: throw IllegalStateException("ยังไม่ได้เชื่อมต่อ")
        val r = d.shell(cmd)
        r.output + r.errorOutput
    }

    suspend fun install(file: File): String = withContext(Dispatchers.IO) {
        val d = dadb ?: throw IllegalStateException("ยังไม่ได้เชื่อมต่อ")
        d.install(file)
        "ติดตั้งสำเร็จ: ${file.name}"
    }

    fun close() {
        runCatching { dadb?.close() }
        dadb = null
    }

    /** สแกนหาอุปกรณ์ที่เปิดพอร์ต 5555 ในวง Wi-Fi เดียวกัน */
    suspend fun scan(): List<String> = withContext(Dispatchers.IO) {
        val base = localBase() ?: return@withContext emptyList<String>()
        coroutineScope {
            (1..254).map { i ->
                async {
                    val ip = "$base.$i"
                    try {
                        Socket().use { it.connect(InetSocketAddress(ip, 5555), 400) }
                        ip
                    } catch (e: Exception) {
                        null
                    }
                }
            }.awaitAll().filterNotNull()
        }
    }
}
