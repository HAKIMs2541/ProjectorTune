package app.projectortune.launcher

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

/** ใช้แตะ/ปัดบนหน้าจอโปรเจคเตอร์ และกดย้อนกลับในแอปอื่น (เปิดให้เองตอนติดตั้งครั้งแรก) */
class TuneAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile
        var instance: TuneAccessibilityService? = null
    }

    override fun onServiceConnected() {
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    fun back() {
        performGlobalAction(GLOBAL_ACTION_BACK)
    }

    fun tap(xf: Float, yf: Float) {
        val dm = resources.displayMetrics
        val p = Path()
        p.moveTo(xf.coerceIn(0f, 1f) * dm.widthPixels, yf.coerceIn(0f, 1f) * dm.heightPixels)
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 60))
            .build()
        dispatchGesture(g, null, null)
    }

    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long) {
        val dm = resources.displayMetrics
        val p = Path()
        p.moveTo(x1.coerceIn(0f, 1f) * dm.widthPixels, y1.coerceIn(0f, 1f) * dm.heightPixels)
        p.lineTo(x2.coerceIn(0f, 1f) * dm.widthPixels, y2.coerceIn(0f, 1f) * dm.heightPixels)
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, ms.coerceIn(80L, 1500L)))
            .build()
        dispatchGesture(g, null, null)
    }
}
