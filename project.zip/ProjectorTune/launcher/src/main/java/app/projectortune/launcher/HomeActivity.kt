package app.projectortune.launcher

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView

/** หน้าหลักแบบคลีน แถวไอคอนเดียว ไม่มีโฆษณา (ควบคุมด้วยรีโมตหรือมือถือ) */
class HomeActivity : Activity(), Navigable {
    private lateinit var row: LinearLayout
    private lateinit var status: TextView
    private val ui = Handler(Looper.getMainLooper())
    private var sw = 1280
    private var sh = 720

    private val tick = object : Runnable {
        override fun run() {
            refreshStatus()
            ui.postDelayed(this, 4000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dm = resources.displayMetrics
        sw = dm.widthPixels
        sh = dm.heightPixels
        buildUi()
        handleIntent(intent)
        try {
            HostService.start(this)
        } catch (e: Throwable) {
        }
        enableAccessibility()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        val t = i?.getStringExtra("pt_token") ?: return
        if (Regex("[0-9a-f]{16,64}").matches(t)) Store.addToken(this, t)
    }

    override fun onResume() {
        super.onResume()
        Top.activity = this
        populate()
        ui.post(tick)
    }

    override fun onPause() {
        ui.removeCallbacks(tick)
        if (Top.activity === this) Top.activity = null
        super.onPause()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // หน้าหลักไม่ต้องย้อนกลับ
    }

    private fun px(f: Float) = sh * f

    private fun text(s: String, sizeF: Float, color: Int): TextView {
        val t = TextView(this)
        t.text = s
        t.setTextColor(color)
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, px(sizeF))
        return t
    }

    private fun buildUi() {
        val root = FrameLayout(this)
        root.clipChildren = false
        root.background = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(0xFF1B2540.toInt(), 0xFF0B0D14.toInt(), 0xFF000000.toInt())
        )
        val m = (sw * 0.05f).toInt()

        val title = text("หน้าหลัก", 0.032f, 0xFFAEAEB2.toInt())
        root.addView(
            title,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.START
            ).also { it.setMargins(m, m / 2, 0, 0) }
        )

        val clock = TextClock(this)
        clock.format24Hour = "HH:mm"
        clock.format12Hour = "HH:mm"
        clock.setTextColor(Color.WHITE)
        clock.setTextSize(TypedValue.COMPLEX_UNIT_PX, px(0.07f))
        root.addView(
            clock,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.END
            ).also { it.setMargins(0, m / 3, m, 0) }
        )

        val scroll = HorizontalScrollView(this)
        scroll.isHorizontalScrollBarEnabled = false
        scroll.clipChildren = false
        scroll.clipToPadding = false
        row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.clipChildren = false
        row.setPadding(m, (sh * 0.06f).toInt(), m, (sh * 0.06f).toInt())
        scroll.addView(row, ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(
            scroll,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER_VERTICAL
            )
        )

        status = text("", 0.024f, 0xFF8E8E93.toInt())
        root.addView(
            status,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM or Gravity.START
            ).also { it.setMargins(m, 0, 0, m / 2) }
        )

        val credit = text("ProjectorTune · by HAKIM", 0.022f, 0xFF636366.toInt())
        root.addView(
            credit,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM or Gravity.END
            ).also { it.setMargins(0, 0, m, m / 2) }
        )
        setContentView(root)
    }

    private fun roundBg(fill: Int, stroke: Int?, r: Float): GradientDrawable {
        val g = GradientDrawable()
        g.cornerRadius = r
        g.setColor(fill)
        if (stroke != null) g.setStroke((sh * 0.006f).toInt().coerceAtLeast(2), stroke)
        return g
    }

    private fun tile(label: String, icon: Drawable?, onClick: () -> Unit): View {
        val tw = (sw / 6.5f).toInt()
        val iw = (tw * 0.82f).toInt()
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER_HORIZONTAL
        box.isFocusable = true
        box.isClickable = true
        box.layoutParams = LinearLayout.LayoutParams(tw, ViewGroup.LayoutParams.WRAP_CONTENT)
            .also { it.setMargins(tw / 14, 0, tw / 14, 0) }

        val img = ImageView(this)
        img.setImageDrawable(icon)
        img.scaleType = ImageView.ScaleType.FIT_CENTER
        val pad = iw / 7
        img.setPadding(pad, pad, pad, pad)
        img.background = roundBg(0x26FFFFFF, null, iw * 0.22f)
        box.addView(img, LinearLayout.LayoutParams(iw, iw))

        val txt = text(label, 0.026f, 0xFFAEAEB2.toInt())
        txt.maxLines = 1
        txt.ellipsize = android.text.TextUtils.TruncateAt.END
        txt.gravity = Gravity.CENTER
        txt.setPadding(0, (sh * 0.015f).toInt(), 0, 0)
        box.addView(txt, LinearLayout.LayoutParams(tw, ViewGroup.LayoutParams.WRAP_CONTENT))

        box.setOnClickListener { onClick() }
        box.setOnFocusChangeListener { _, focused ->
            val s = if (focused) 1.12f else 1f
            box.animate().scaleX(s).scaleY(s).setDuration(120).start()
            img.background = if (focused) {
                roundBg(0x40FFFFFF, Color.WHITE, iw * 0.22f)
            } else {
                roundBg(0x26FFFFFF, null, iw * 0.22f)
            }
            txt.setTextColor(if (focused) Color.WHITE else 0xFFAEAEB2.toInt())
        }
        return box
    }

    private fun populate() {
        row.removeAllViews()
        for (a in Apps.list(this)) {
            row.addView(tile(a.label, a.icon) { Apps.launch(this, a.pkg, a.cls) })
        }
        row.addView(
            tile("ตั้งค่า", getDrawable(android.R.drawable.ic_menu_preferences)) {
                try {
                    startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (e: Throwable) {
                }
            }
        )
        if (currentFocus == null) row.getChildAt(0)?.requestFocus()
    }

    private fun refreshStatus() {
        val s = "รหัสจับคู่ ${Store.pin(this)}  ·  ${Net.localIp()}  ·  " +
            if (HostService.connected) "มือถือเชื่อมต่ออยู่" else "รอการเชื่อมต่อจากแอป ProjectorTune"
        status.text = s
    }

    override fun nav(k: String): Boolean {
        val f = currentFocus
        if (f == null) {
            row.getChildAt(0)?.requestFocus()
            return true
        }
        when (k) {
            "LEFT" -> f.focusSearch(View.FOCUS_LEFT)?.requestFocus()
            "RIGHT" -> f.focusSearch(View.FOCUS_RIGHT)?.requestFocus()
            "OK" -> f.performClick()
            "UP", "DOWN" -> {
            }
            else -> return false
        }
        return true
    }

    /** เปิดบริการช่วยการเข้าถึงให้เอง (ใช้สิทธิ์ที่แอปมือถือมอบให้ตอนติดตั้ง) */
    private fun enableAccessibility() {
        try {
            val cn = ComponentName(this, TuneAccessibilityService::class.java).flattenToString()
            val cur = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
            if (!cur.split(':').contains(cn)) {
                val v = if (cur.isEmpty()) cn else "$cur:$cn"
                Settings.Secure.putString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, v)
                Settings.Secure.putInt(contentResolver, Settings.Secure.ACCESSIBILITY_ENABLED, 1)
            }
        } catch (e: Throwable) {
        }
    }
}
